"""The Inscriptis Web service."""
